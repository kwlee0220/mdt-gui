import http from "./client";

const urls = {
  aas: "/proxy/shell-registry/shell-descriptors",
  submodel: "/proxy/submodel-registry/submodel-descriptors",
  simulation: "/proxy/api/v1/simulation",
  instance: "/proxy/instance-manager/instances",
  workflow: "/proxy/workflow-manager/descriptors",
  workflow_builtin: "/proxy/workflow-manager/builtin-tasks",
  node_submodel: "/node/api/relation",
  users: "/node/api/users",
};

export default urls;

export const get_test = () => http.get("/api/list/goods");

//#region Users API
export const req_login = (data) => http.post(`${urls.users}/login`, data);
export const get_users_all = () => http.get(`${urls.users}`);
export const get_users = (userid) => http.get(`${urls.users}/${userid}`);
export const post_users = (data) => http.post(`${urls.users}`, data);
export const put_users = (userid, data) =>
  http.put(`${urls.users}/${userid}`, data);
export const delete_users = (userid) => http.delete(`${urls.users}/${userid}`);
//#endregion

/**
 * AAS API
 */
export const get_aas_all = () => http.get(`${urls.aas}`);
export const get_aas = (shortId) => http.get(`${urls.ass}/?idShort=${shortId}`);

/**
 * SubModel API
 */
export const get_submodel_all = () => http.get(`${urls.submodel}`);
export const get_submodel = (shortId) =>
  http.get(`${urls.submodel}?idShort=${shortId}`);

export const get_node_relation_submodel = (data) =>
  http.post(`${urls.node_submodel}`, data);

/**
 * Simulation API
 */
export const get_simulation = (param) => http.get(`${urls.simulation}${param}`);
export const delete_simulation = (id, opid) =>
  http.delete(`${urls.simulation}?id=${id}&opId=${opid}`);

/**
 * Instance API
 */
export const get_instance_all = () => http.get(`${urls.instance}`);
export const get_instance = (id) => http.get(`${urls.instance}/${id}`);
export const add_instance = (data) => http.post(`${urls.instance}`, data);
export const delete_instance_all = () => http.delete(`${urls.instance}`);
export const delete_instance = (id) => http.delete(`${urls.instance}/${id}`);
export const start_instance = (id) => http.put(`${urls.instance}/${id}/start`);
export const stop_instance = (id) => http.put(`${urls.instance}/${id}/stop`);

export const get_instance_submodel_descriptors = (id) =>
  http.get(`${urls.instance}/${id}/submodel_descriptors`);
export const get_instance_ass_descriptor = (id) =>
  http.get(`${urls.instance}/${id}/ass_descriptor`);
export const get_instance_stdout = (id) =>
  http.get(`${urls.instance}/${id}/log`);
export const get_instance_stderr = (id) =>
  http.get(`${urls.instance}/${id}/stderr`);

export const get_start_instance = (id) =>
  http.get(`${urls.instance}/${id}/start`);
export const get_stop_instance = (id) =>
  http.get(`${urls.instance}/${id}/stop`);

/**
 * Workflow API
 */
export const get_workflow_all = () => http.get(`${urls.workflow}`);
export const get_workflow = (id) => http.get(`${urls.workflow}/${id}`);
export const add_workflow = (data) => http.post(`${urls.workflow}/`, data);
export const delete_workflow_all = () => http.delete(`${urls.workflow}`);
export const delete_workflow = (id) => http.delete(`${urls.workflow}/${id}`);
export const get_workflow_argo = (id) =>
  http.get(`${urls.workflow}/${id}/argo`);
export const get_workflow_built_in_all = () =>
  http.get(`${urls.workflow_builtin}`);
export const get_workflow_built_in = (id) =>
  http.get(`${urls.workflow_builtin}/${id}`);
