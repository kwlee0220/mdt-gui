import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";
import modal_icon from "assets/images/logo/header_icon.png";
import LogView from "../Instance/LogView";
import useRequestManager from "apps/utils/request_manager";
import SubModelTree from "../Instance/SubModelTree";

const ModalWorkflowInfo = ({ open, closeModal, data }) => {
  const [workflow, setWorkflow] = useState();
  const [tasks, setTasks] = useState("");

  //#region 데이터 조회

  //#endregion

  useEffect(() => {
    if (data) {
      setWorkflow(data);
      setTasks(data.tasks);
    }
  }, [data]);

  return (
    <Modal show={open} centered animation={false} size={"lg"}>
      <Modal.Header>
        <div className="header-icon">
          <i className="ph-app-window"></i>
        </div>
        <div className="modal-title">워크플로우 정보</div>
        <button
          type="button"
          className="btn btn-link ms-auto"
          onClick={closeModal}
        >
          <i className="ph-x"></i>
        </button>
      </Modal.Header>
      <Modal.Body>
        <div className="contents-part mb-4">
          <div className="table-container">
            <table className="table mb-0">
              <thead>
                <tr>
                  <td>기본정보</td>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>
                    <div className="row">
                      <label className="col-form-label col-2">ID</label>
                      <label className="col-form-label col-10 label-value">
                        {workflow ? workflow.id : ""}
                      </label>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="row">
                      <label className="col-form-label col-2">Name</label>
                      <label className="col-form-label col-10 label-value">
                        {workflow ? workflow.name : ""}
                      </label>
                    </div>
                  </td>
                </tr>
                <tr>
                  <td>
                    <div className="row">
                      <label className="col-form-label col-2">
                        Description
                      </label>
                      <label className="col-form-label col-10 label-value">
                        {workflow ? workflow.description : ""}
                      </label>
                    </div>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
        <div className="contents-part">
          <div className="contents-title">
            <div className="title">
              <img src={modal_icon} className="me-2" height={16}></img>
              <span>Tasks 정보</span>
            </div>
          </div>
          <div className="table-container">
            <table className="table mb-0">
              <tbody>
                <tr>
                  <td>
                    <SubModelTree data={tasks ? tasks : []}></SubModelTree>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <button className="btn btn-link" onClick={closeModal}>
          닫기
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default ModalWorkflowInfo;
