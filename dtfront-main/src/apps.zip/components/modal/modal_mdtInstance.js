import { useEffect, useState } from "react";
import { Modal } from "react-bootstrap";

const ModalMDTInstance = ({ open, closeModal, handleAddInstance }) => {
  const [inputData, setInputData] = useState();

  const handleAdd = () => {
    handleAddInstance(inputData, "add");
  };

  useEffect(() => {
    if (open) {
    }

    return () => {
      setInputData(null);
    };
  }, [open]);

  return (
    <Modal show={open} centered animation={false}>
      <Modal.Header>
        <div className="header-icon">
          <i className="ph-app-window"></i>
        </div>
        <div className="modal-title">MDT 인스턴스 추가</div>
        <button
          type="button"
          className="btn btn-link ms-auto"
          onClick={closeModal}
        >
          <i className="ph-x"></i>
        </button>
      </Modal.Header>
      <div>
        <table className="table table-border">
          <tbody>
            <tr>
              <td>ID</td>
              <td>
                <input type="text" className="form-control"></input>
              </td>
            </tr>
            <tr>
              <td>Port</td>
              <td>
                <input type="number" className="form-control"></input>
              </td>
            </tr>
            <tr>
              <td>모델파일</td>
              <td>
                <input type="file" className="form-control"></input>
              </td>
            </tr>
            <tr>
              <td>설정파일</td>
              <td>
                <input type="file" className="form-control"></input>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      <Modal.Footer>
        <button className="btn btn-success" onClick={handleAdd}>
          등록
        </button>
        <button className="btn btn-link" onClick={closeModal}>
          닫기
        </button>
      </Modal.Footer>
    </Modal>
  );
};

export default ModalMDTInstance;
