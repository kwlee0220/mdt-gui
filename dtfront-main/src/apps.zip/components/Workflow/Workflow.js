import {
  applyEdgeChanges,
  applyNodeChanges,
  Background,
  ConnectionLineType,
  Controls,
  MarkerType,
  ReactFlow,
  useEdgesState,
  useNodesState,
  useReactFlow,
} from "@xyflow/react";
import moment from "moment";

import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react";
import useDataManager from "apps/utils/data_manager";
import TreeView from "../Tree/TreeView";
import {
  useGenesisDataManager,
  WorkflowNodeType,
} from "apps/datas/definedData";
import ModalNode from "../modal/modal_node";
import useModal from "../modal/useModal";

const getId = () => {
  let name = "node_" + moment().valueOf();

  return name;
};
const getLineID = () => {
  let name = "line_" + moment().valueOf();

  return name;
};

const edgeType = {};

const nodeInfo = {
  id: "",
  type: "",
  position: "",
  style: {},
  data: {
    label: "",
  },
};

const Workflow = forwardRef(({}, ref) => {
  const { GET_TASKLABEL, GET_NODETYPE } = useGenesisDataManager();

  const modalNodeInfo = useModal();

  //#region Tree 관련

  const { GET_DATA_SOURCE_TREE, GET_DATA_TARGET_TREE } = useDataManager();
  const [viewTree, setViewTree] = useState(false);

  //#endregion

  const reactFlowWrapper = useRef(null);

  useImperativeHandle(ref, () => ({
    onSaveFlowData,
    onLoadFlowData,
    onClearFlow,
  }));

  const { getNode, setViewport } = useReactFlow();

  const [nodes, setNodes] = useNodesState([]);
  const [edges, setEdges] = useEdgesState([]);
  const [reactFlowInstance, setReactFlowInstance] = useState(null);
  const [selectedNode, setSelectedNode] = useState();

  const [sourceTreeData, setSourceTreeData] = useState();
  const [targetTreeData, setTargetTreeData] = useState();

  /********************************
   *
   * Flow Data 관리 함수
   *
   **********************************/
  const onClearFlow = useCallback(() => {
    setNodes([]);
    setEdges([]);
  }, [setNodes, setEdges]);

  const onSaveFlowData = useCallback(() => {
    if (reactFlowInstance) {
      const flow = reactFlowInstance.toObject();
      localStorage.setItem("exam-flow", JSON.stringify(flow));

      console.log("Flow Data", flow);
    }
  }, [reactFlowInstance]);

  const onLoadFlowData = useCallback(() => {
    const restoreFlow = async () => {
      const flow = JSON.parse(localStorage.getItem("exam-flow"));

      if (flow) {
        const { x = 0, y = 0, zoom = 1 } = flow.viewport;

        setNodes(flow.nodes || []);
        setEdges(flow.edges || []);
        setViewport({ x, y, zoom });
      }
    };

    restoreFlow();
  }, [setNodes, setViewport]);

  /********************************
   *
   * Node 다이얼로그 함수
   *
   **********************************/
  const getDefaultNodeData = (item) => {
    let result = {
      label: GET_TASKLABEL(item.type),
      item: item,
      onShowNodeSetting: onClickNodeSetting,
    };

    return result;
  };

  const onClickNodeSetting = (id, data) => {
    setSelectedNode({
      id: id,
      data: data,
    });

    modalNodeInfo.toggleModal();
  };

  const onClickModifyNodeInfo = (id, data) => {
    console.log("Node Modify", id, data);

    setNodes((nds) =>
      nds?.map((node) => {
        if (node.id === id) {
          return {
            ...node,
            data: {
              ...node.data,
              label: data.label,
            },
          };
        }

        return node;
      })
    );
  };

  /********************************
   *
   * ReactFlow 이벤트 함수
   *
   **********************************/
  const onNodesChange = useCallback(
    (changes) => setNodes((nds) => applyNodeChanges(changes, nds)),
    [setNodes]
  );
  const onEdgesChange = useCallback(
    (changes) => setEdges((eds) => applyEdgeChanges(changes, eds)),
    [setEdges]
  );

  const onConnect = useCallback(
    (params) => {
      console.log("Connect", params);
      const { source, target } = params;

      let node_source = getNode(source);
      let node_target = getNode(target);

      console.log(node_source, node_target);

      const newLine = {
        ...params,
        id: getLineID(),
        type: ConnectionLineType.SmoothStep,
        markerEnd: {
          type: MarkerType.ArrowClosed,
          width: 20,
          height: 20,
          color: "#FF0072",
        },
        data: {
          label: "",
        },
        style: {
          strokeWidth: 2,
          stroke: "#FF0072",
        },
      };

      if (node_source.type === "decision") {
        newLine.type = "editable";
        newLine.data.label = "YES";
      }

      setEdges((eds) => eds?.concat(newLine));
    },
    [setEdges]
  );

  const onDragOver = useCallback((event) => {
    event.preventDefault();
    event.dataTransfer.dropEffect = "move";
  }, []);

  const onDrop = useCallback(
    (event) => {
      event.preventDefault();

      const item = event.dataTransfer.getData("application/reactflow");

      if (typeof item === "undefined" || !item) {
        return;
      }

      var info = null;

      try {
        info = JSON.parse(item);
      } catch {}

      if (info === null) {
        return;
      }

      const position = reactFlowInstance.screenToFlowPosition({
        x: event.clientX,
        y: event.clientY,
      });
      const newNode = {
        id: getId(),
        type: GET_NODETYPE(info.type),
        position,
        data: getDefaultNodeData(info),
      };

      setNodes((nds) => nds?.concat(newNode));
    },
    [reactFlowInstance]
  );

  const onNodeClick = (event, node) => {
    //console.log("Click Node", event, node);
  };

  const onEdgeDoubleClick = (event, edge) => {
    let source = null;
    let target = null;

    source = getNode(edge.source);
    target = getNode(edge.target);

    console.log("Source", source);
    console.log("Target", target);

    setSourceTreeData(GET_DATA_SOURCE_TREE);
    setTargetTreeData(GET_DATA_TARGET_TREE);

    setViewTree(true);
  };

  const onClickCloseTree = () => {
    setViewTree(false);
  };

  useEffect(() => {}, [sourceTreeData, targetTreeData]);

  return (
    <div
      className="card card-body pnl-workflow-workspace"
      ref={reactFlowWrapper}
    >
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        onConnect={onConnect}
        onInit={setReactFlowInstance}
        onDrop={onDrop}
        onDragOver={onDragOver}
        onNodeClick={onNodeClick}
        onEdgeDoubleClick={onEdgeDoubleClick}
        minZoom={0.4}
        maxZoom={4}
        fitView
        connectionLineType={ConnectionLineType.SmoothStep}
        nodeTypes={WorkflowNodeType}
        edgeTypes={edgeType}
        deleteKeyCode={["Backspace", "Delete"]}
      >
        <Background color="#777" gap={16} />
        <Controls />
      </ReactFlow>

      {viewTree && (
        <div className="pnl-network-connect">
          <div className="card mb-0">
            <div className="card-header d-flex align-items-center">
              <h6 className="mb-0">SubModel 연결 정보</h6>
              <div className="d-inline-flex ms-auto">
                <div
                  className="text-body cursor-pointer"
                  onClick={onClickCloseTree}
                >
                  <i className="ph-x"></i>
                </div>
              </div>
            </div>
            <div className="card-body row">
              <div className="col d-column">
                <h6>Source</h6>
                <TreeView list={sourceTreeData} />
              </div>
              <div className="col d-column">
                <h6>Target</h6>
                <TreeView list={targetTreeData} />
              </div>
            </div>
          </div>
        </div>
      )}

      <ModalNode
        node={selectedNode}
        open={modalNodeInfo.open}
        closeModal={modalNodeInfo.toggleModal}
        handleModify={onClickModifyNodeInfo}
      ></ModalNode>
    </div>
  );
});

export default Workflow;
