import { Handle, Position } from "@xyflow/react";
import { memo } from "react";
import clsx from "classnames";

const NodeAas = ({ id, data, selected }) => {
  const onClickSetting = (e) => {
    e.preventDefault();

    if (data.onShowNodeSetting) {
      console.log("Click Setting", data);

      data.onShowNodeSetting(id, data);
    }
  };

  return (
    <div className="pnl-default-node">
      <div className="btn-node-setting">
        <button
          className="btn btn-flat-secondary btn-icon btn-sm"
          onClick={onClickSetting}
        >
          <i className="ph-gear"></i>
        </button>
      </div>
      <Handle type="target" position={Position.Top} id="top" />
      <Handle type="target" position={Position.Left} id="left" />

      <Handle type="source" position={Position.Right} id="right" />
      <Handle type="source" position={Position.Bottom} id="bottom" />
      <div className="node-wrapper">
        <div className="node-label">{data?.label || ""}</div>
        <div className="task-label">Task</div>
      </div>
    </div>
  );
};

export default memo(NodeAas);
