import { useEffect, useState } from "react";
import clsx from "classnames";
import { TreeItemType } from "apps/datas/definedData";

const TreeNode = ({ node, clickNode }) => {
  const [typeLabel, setTypeLabel] = useState();
  const [typeBG, setTypeBG] = useState();
  const [isExpanded, setIsExpanded] = useState(false);

  const hasChildren = node.children && node.children.length > 0;

  const initData = (data) => {
    let label = "";
    let bg = "";

    switch (data.type) {
      case TreeItemType.MDT:
        label = "MDT";
        bg = "bg-primary";
        break;
      case TreeItemType.SubModel:
        label = "MODEL";
        bg = "bg-success";
        break;
      case TreeItemType.Element:
        label = "ELEMENT";
        bg = "bg-indigo";
        break;
      default:
        break;
    }

    setTypeLabel(label);
    setTypeBG(bg);
  };

  const handleClick = () => {
    if (!isExpanded) {
      if (clickNode) {
        clickNode(node);
      }
    }
    setIsExpanded(!isExpanded);
  };

  useEffect(() => {
    if (node) {
      initData(node);
    }
  }, [node]);

  return (
    <div className="tree-parent ms-2">
      {/* 노드를 클릭하면 확장/축소 */}
      <div onClick={handleClick} className="tree-label">
        {hasChildren && (
          <span style={{ marginRight: 5 }}>{isExpanded ? "-" : "+"}</span>
        )}
        <span className={clsx("badge me-2", typeBG)}>{typeLabel}</span>
        {node.label}
      </div>

      {/* 자식 노드를 렌더링 */}
      {isExpanded && hasChildren && (
        <div style={{ marginLeft: 10 }} className="tree-child">
          {node.children.map((childNode) => (
            <TreeNode
              key={childNode.id}
              node={childNode}
              clickNode={clickNode}
            />
          ))}
        </div>
      )}
    </div>
  );
};

export default TreeNode;
