import { useEffect, useState } from "react";
import SubModelTree from "../SubModelTree";
import modal_icon from "assets/images/logo/header_icon.png";
import LogView from "../LogView";
import MDIStatusCard from "../MDIStatusCard";
import useRequestManager from "apps/utils/request_manager";

const PageInstanceInfo = ({ instance, closeInfo }) => {
  const [instanceInfo, setInstanceInfo] = useState();
  const [assInfo, setAssInfo] = useState();
  const [subModel, setSubModel] = useState();
  const [logError, setLogError] = useState();
  const [logOut, setLogOut] = useState();

  //#region 데이터 조회

  const {
    REQ_Instance_GET_Stderr,
    REQ_Instance_GET_Stdout,
    REQ_Instance_GET_Submodel_Descriptors,
    REQ_Instance_GET_Ass_Descriptor,
  } = useRequestManager();

  const fetchAss = async () => {
    let result = await REQ_Instance_GET_Ass_Descriptor(instance.id);

    if (result) {
      console.log("fetchAss", result);
      setSubModel(result);
    }
  };

  const fetchSubModels = async () => {
    let result = await REQ_Instance_GET_Submodel_Descriptors(instance.id);

    if (result) {
      console.log("fetchSubModels", result);
      setSubModel(result);
    }
  };

  const fetchStdout = async () => {
    let result = await REQ_Instance_GET_Stdout(instance.id);

    if (result) {
      console.log("fetchStdout", result);

      setLogOut(result);
    }
  };

  const fetchStderr = async () => {
    let result = await REQ_Instance_GET_Stderr(instance.id);

    if (result) {
      console.log("fetchStderr", result);
    }
  };

  //#endregion

  const makeData = (info) => {
    setInstanceInfo(info);

    fetchAss();
    fetchSubModels();
    fetchStdout();
    fetchStderr();
  };

  useEffect(() => {
    if (instance) {
      console.log(instance);
      makeData(instance);
    }
  }, [instance]);

  return (
    <div>
      <div className="page-title">
        <img src={modal_icon}></img>
        <div className="title">MDT 인스턴스 정보</div>
        <button
          className="btn btn-info btn-icon width-100 ms-auto"
          onClick={closeInfo}
        >
          <i className="ph-x me-2"></i>
          닫기
        </button>
      </div>

      <div className="contents-part">
        <MDIStatusCard
          type={instanceInfo ? instanceInfo.status : "STOPPED"}
          instanceInfo={instanceInfo}
        ></MDIStatusCard>
      </div>
      <div className="row">
        <div className="col-6">
          <div className="contents-part">
            <div className="contents-title">
              <div className="title">
                <img src={modal_icon} className="me-2" height={16}></img>
                <span>로그뷰</span>
              </div>
            </div>
            <div className="table-container">
              <LogView data={logOut ? logOut : ""}></LogView>
            </div>
          </div>
        </div>
        <div className="col-6">
          <div className="contents-part">
            <div className="contents-title">
              <div className="title">
                <img src={modal_icon} className="me-2" height={16}></img>
                <span>SubModel 트리</span>
              </div>
            </div>
            <div className="table-container">
              <SubModelTree data={subModel ? subModel : []}></SubModelTree>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PageInstanceInfo;
