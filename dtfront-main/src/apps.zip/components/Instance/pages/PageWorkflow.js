import WorkflowTable from "apps/components/Table/WorkflowTable";
import useRequestManager from "apps/utils/request_manager";
import { useEffect, useState } from "react";

const PageWorkflow = () => {

  //#region 데이터 조회 및 테이블 관련

  const [originList, setOriginList] = useState([]);
  const [datalist, setDatalist] = useState([]);

  //#endregion

  useEffect(() => {}, []);

  return <div>
      <WorkflowTable list={datalist}></WorkflowTable>
  </div>;
};

export default PageWorkflow;
