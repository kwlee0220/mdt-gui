import moment from "moment";

const UtilManager = () => {
  const CloneDeep = (obj) => {
    let origin = obj;

    try {
      origin = JSON.parse(JSON.stringify(origin));
    } catch {}

    return origin;
  };

  const ADD_COMMA = (num) => {
    if (num) {
      var regexp = /\B(?=(\d{3})+(?!\d))/g;
      return num.toString().replace(regexp, ",");
    }

    return "";
  };

  const InRange_Number = (min, max) => {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  };

  const InRange_Float = (min, max) => {
    return (Math.random() * (max - min + 1) + min).toFixed(2);
  };

  const GET_NOW_STR = () => {
    return moment().format("YYYY-MM-DD HH:mm:ss");
  };

  const GET_DATE_TO_STR = (date, format) => {
    let result = date;

    if (result) {
      try {
        result = moment(result, "YYYYMMDD HH:mm:ss").format(format);

        if (result === "Invalid date") {
          result = date;
        }
      } catch {}
    }

    return result;
  };

  const GET_NULL_CHECK = (data, result = "") => {
    if (data && data.length > 0) {
      return data;
    }

    return result;
  };

  const IS_NULL = (data) => {
    let result = false;

    if (data === undefined || data === null || data.length === 0) {
      result = true;
    }

    return result;
  };

  const IS_NUMBER = (data) => {
    let check = false;
    const regex = /^[0-9]+$/;

    if (!regex.test(data)) {
      return check;
    }

    const value = Number(data);

    if (Number.isNaN(value)) {
      return check;
    }

    check = true;

    return check;
  };

  const IS_INCLUDE = (base, search) => {
    let result = false;

    if (base && search) {
      if (base.toLowerCase().includes(search.toLowerCase())) {
        return true;
      }
    }

    return result;
  };

  const GET_COMPACT = (modellist) => {
    let result = "";

    let count_info = 0;
    let count_ai = 0;
    let count_sim = 0;
    let count_bhv = 0;
    let count_data = 0;
    let count_shape = 0;

    let list = modellist.map((item) => {
      let label = item.idShort;
      let type = "";

      try {
        const match = item.semanticId.match(/\/([^\/]+)\/1\/1/);
        if (match) {
          type = match[1];
        }
      } catch {}

      switch (type.toLowerCase()) {
        case "informationmodel":
          label = "[ Info ] " + label;
          count_info++;
          break;
        case "ai":
          label = "[ AI ] " + label;
          count_ai++;
          break;
        case "simulation":
          label = "[ Sim ] " + label;
          count_sim++;
          break;
        case "behavior":
          label = "[ Bhv ] " + label;
          count_bhv++;
          break;
        case "data":
          label = "[ Data ] " + label;
          count_data++;
          break;
        case "shape":
          label = "[ Shp ] " + label;
          count_shape++;
          break;
        default:
          break;
      }

      return label;
    });

    list = [];

    if (count_info > 0) {
      list.push("Info(" + count_info + ")");
    }

    if (count_ai > 0) {
      list.push("AI(" + count_ai + ")");
    }

    if (count_sim > 0) {
      list.push("Sim(" + count_sim + ")");
    }

    if (count_bhv > 0) {
      list.push("Bhv(" + count_bhv + ")");
    }

    if (count_data > 0) {
      list.push("Data(" + count_data + ")");
    }

    if (count_shape > 0) {
      list.push("Shp(" + count_shape + ")");
    }

    result = list.join(", ");

    return result;
  };

  const GET_MODELTYPE = (item) => {
    let label = "";
    let type = "";

    try {
      const match = item.semanticId.match(/\/([^\/]+)\/1\/1/);
      if (match) {
        type = match[1];
      }
    } catch {}

    /*
    switch (type.toLowerCase()) {
      case "informationmodel":
        label = "Info";
        break;
      case "aimodel":
        label = "AI";
        break;
      case "simulation":
        label = "Sim";
        break;
      case "behavior":
        label = "Bhv";
        break;
      case "data":
        label = "Data";
        break;
      case "shape":
        label = "Shp";
        break;
      default:
        break;
    }
        */

    return type;
  };

  return {
    CloneDeep,
    GET_MODELTYPE,
    GET_DATE_TO_STR,
    GET_NOW_STR,
    GET_NULL_CHECK,
    IS_NULL,
    IS_NUMBER,
    InRange_Float,
    InRange_Number,
    ADD_COMMA,
    IS_INCLUDE,
    GET_COMPACT,
  };
};

export default UtilManager;
