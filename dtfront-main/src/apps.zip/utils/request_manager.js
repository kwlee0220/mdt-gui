import {
  get_aas,
  get_submodel,
  get_node_relation_submodel,
  get_simulation,
  delete_simulation,
  get_instance,
  get_instance_all,
  start_instance,
  stop_instance,
  get_instance_ass_descriptor,
  get_instance_stderr,
  get_instance_stdout,
  get_instance_submodel_descriptors,
  get_workflow_all,
  get_workflow_argo,
  req_login,
  get_users_all,
  get_users,
  post_users,
  put_users,
  delete_users,
  delete_instance,
  add_instance,
} from "apps/remote/urls";

const useRequestManager = () => {
  const GET_RESULT = (resp) => {
    let result = {
      error: "Error",
      status: resp.status,
      data: resp.data,
    };

    return result;
  };

  //#region Auth API

  const REQ_LOGIN = async (data) => {
    let result;

    try {
      const resp = await req_login(data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_LOGIN ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Users API

  const REQ_GET_USERS_ALL = async () => {
    let result;

    try {
      const resp = await get_users_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_GET_USERS_ALL ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_GET_USERS = async (userid) => {
    let result;

    try {
      const resp = await get_users(userid);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_GET_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_POST_USERS = async (data) => {
    let result;

    try {
      const resp = await post_users(data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_POST_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_PUT_USERS = async (userid, data) => {
    let result;

    try {
      const resp = await put_users(userid, data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_PUT_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  const REQ_DELETE_USERS = async (userid) => {
    let result;

    try {
      const resp = await delete_users(userid);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_DELETE_USERS ERROR", e.response);

        result = GET_RESULT(e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region AAS API

  const REQ_AAS_GET = async (id) => {
    let result;

    try {
      const resp = await get_aas(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_AAS_GET ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region SubModel API

  const REQ_SubModel_GET = async (id) => {
    let result;

    try {
      const resp = await get_submodel(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_SubModel_GET ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Node_SubModel_GET = async (data) => {
    let result;

    try {
      const resp = await get_node_relation_submodel(data);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Node_SubModel_GET ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Simulation API

  const REQ_Simulation_GET = async (param) => {
    let result;

    try {
      const resp = await get_simulation(param);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Simulation_GET ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Simulation_DELETE = async (id, opid) => {
    let result;

    try {
      const resp = await delete_simulation(id, opid);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Simulation_DELETE ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Instance API

  const REQ_Instance_GET = async (id) => {
    let result;

    try {
      const resp = await get_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_ALL = async () => {
    let result;

    try {
      const resp = await get_instance_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_ALL ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_START = async (id) => {
    let result;

    try {
      const resp = await start_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_START ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_STOP = async (id) => {
    let result;

    try {
      const resp = await stop_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_STOP ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_ADD = async (id) => {
    let result;

    try {
      const resp = await add_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_ADD ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_DELETE = async (id) => {
    let result;

    try {
      const resp = await delete_instance(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_DELETE ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Submodel_Descriptors = async (id) => {
    let result;

    try {
      const resp = await get_instance_submodel_descriptors(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Submodel_Descriptors ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Ass_Descriptor = async (id) => {
    let result;

    try {
      const resp = await get_instance_ass_descriptor(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Ass_Descriptor ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Stdout = async (id) => {
    let result;

    try {
      const resp = await get_instance_stdout(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Stdout ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Instance_GET_Stderr = async (id) => {
    let result;

    try {
      const resp = await get_instance_stderr(id);
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_GET_Stderr ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  //#region Workflow API

  const REQ_Workflow_GET_ALL = async () => {
    let result;

    try {
      const resp = await get_workflow_all();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_STOP ERROR", e.response);
      }
    }

    return result;
  };

  const REQ_Workflow_GET_ARGO = async () => {
    let result;

    try {
      const resp = await get_workflow_argo();
      const resp_data = resp.data;

      result = resp_data;
    } catch (e) {
      if (e.response) {
        console.log("REQ_Instance_STOP ERROR", e.response);
      }
    }

    return result;
  };

  //#endregion

  return {
    // Auth API
    REQ_LOGIN,

    // Users API
    REQ_GET_USERS_ALL,
    REQ_GET_USERS,
    REQ_POST_USERS,
    REQ_PUT_USERS,
    REQ_DELETE_USERS,

    REQ_AAS_GET,

    // Instance API
    REQ_Instance_GET,
    REQ_Instance_GET_ALL,
    REQ_Instance_START,
    REQ_Instance_STOP,
    REQ_Instance_ADD,
    REQ_Instance_DELETE,
    REQ_Instance_GET_Ass_Descriptor,
    REQ_Instance_GET_Submodel_Descriptors,
    REQ_Instance_GET_Stdout,
    REQ_Instance_GET_Stderr,
    REQ_Simulation_DELETE,
    REQ_Simulation_GET,
    REQ_SubModel_GET,

    // SubModel Info API
    REQ_Node_SubModel_GET,

    // Workflow API
    REQ_Workflow_GET_ALL,
    REQ_Workflow_GET_ARGO,
  };
};

export default useRequestManager;
