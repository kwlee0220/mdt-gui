import { ReactFlowProvider } from "@xyflow/react";
import TreeView from "apps/components/Tree/TreeView";
import Workflow from "apps/components/Workflow/Workflow";
import WorkflowTaskItem from "apps/components/Workflow/WorkflowTaskItem";
import {
  TreeItemType,
  useConvert,
  useGenesisDataManager,
} from "apps/datas/definedData";
import useGlobalData from "apps/datas/useGlobalData";
import useRequestManager from "apps/utils/request_manager";
import clsx from "classnames";
import { useEffect, useRef, useState } from "react";

const WorkflowPage = () => {
  const projectFlowRef = useRef();

  const { GET_TASKLIST } = useGenesisDataManager();
  const { CONVERT_MDTLIST_TO_TREELIST, CREATE_TREEITEM } = useConvert();
  const { instanceList } = useGlobalData();

  //#region 데이터 조회

  const { REQ_Node_SubModel_GET } = useRequestManager();

  const fetchSubModel = async (url, id) => {
    const encodeID = btoa(id);
    const path = url + "/submodels/" + encodeID + "?$value";

    let result = await REQ_Node_SubModel_GET({
      url: path,
    });

    let resultlist = [];

    if (result && result.submodelElements) {
      resultlist = result.submodelElements;
    }

    return resultlist;
  };

  //#endregion

  //#region 컴포넌트 Accordion

  const [expandTask, setExpandTask] = useState(true);
  const [expandMDT, setExpandMDT] = useState(true);

  //#endregion

  //#region 리스트 관리

  const [tasklist, setTasklist] = useState([]);
  const [mdtlist, setMdtlist] = useState([]);

  const initData = () => {
    let list = GET_TASKLIST();

    setTasklist(list);

    const treelist = CONVERT_MDTLIST_TO_TREELIST(instanceList);

    setMdtlist(treelist);
  };

  //#endregion

  const onClickClear = () => {
    if (projectFlowRef) {
      projectFlowRef.current.onClearFlow();
    }
  };

  const onClickRun = () => {};

  const onClickLoad = () => {};

  const onClickSave = () => {};

  const onClickNode = async (node) => {
    if (node.type === TreeItemType.SubModel) {
      let parent = node.parent;
      let data = node.data;

      if (parent && parent.data && data) {
        let endpoint = parent.data.baseEndpoint;
        let id = data.id;

        let result = await fetchSubModel(endpoint, id);

        result.forEach((element) => {
          let nodeItem = CREATE_TREEITEM(element, TreeItemType.Element, node);

          node.children.push(nodeItem);
        });
      }

      console.log(node);
    }
  };

  useEffect(() => {
    initData();
  }, []);

  return (
    <div className="main-content px-3">
      <div className="page-header mt-2 border rounded workflow-header">
        <h4 className="me-2 mb-0" style={{ width: "300px" }}>
          Workflow
        </h4>
        <div className="flex-group">
          <div className="btn-toolkit" onClick={onClickClear}>
            <i className="ph-eraser me-2"></i>
            Clear
          </div>
          <div className="btn-toolkit" onClick={onClickRun}>
            <i className="ph-monitor-play me-2"></i>
            Make Script
          </div>
        </div>
        <div className="flex-group ms-auto">
          <div className="btn-toolkit" onClick={onClickLoad}>
            <i className="ph-folder-notch-open me-2"></i>
            Load
          </div>
          <div className="btn-toolkit" onClick={onClickSave}>
            <i className="ph-floppy-disk me-2"></i>
            Save
          </div>
        </div>
      </div>

      <div className="pnl-workflow">
        <ReactFlowProvider>
          <div className="card pnl-workflow-components">
            <div className="accordion">
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button
                    className={clsx(
                      "accordion-button fw-semibold",
                      expandTask ? "" : "collapsed"
                    )}
                    type="button"
                    onClick={() => setExpandTask(!expandTask)}
                  >
                    Task
                  </button>
                </h2>
                <div
                  className={clsx(
                    "accordion-collapse collapse",
                    expandTask ? "show" : ""
                  )}
                >
                  <div className="accordion-body">
                    {tasklist &&
                      tasklist.map((item, index) => {
                        return <WorkflowTaskItem key={index} item={item} />;
                      })}
                  </div>
                </div>
              </div>
            </div>

            <div className="accordion mt-3">
              <div className="accordion-item">
                <h2 className="accordion-header">
                  <button
                    className={clsx(
                      "accordion-button fw-semibold",
                      expandMDT ? "" : "collapsed"
                    )}
                    type="button"
                    onClick={() => setExpandMDT(!expandMDT)}
                  >
                    MDT Instance
                  </button>
                </h2>
                <div
                  className={clsx(
                    "accordion-collapse collapse",
                    expandMDT ? "show" : ""
                  )}
                >
                  <div className="accordion-body p-1">
                    <TreeView list={mdtlist} clickNode={onClickNode}></TreeView>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <Workflow ref={projectFlowRef}></Workflow>
        </ReactFlowProvider>
      </div>
    </div>
  );
};

export default WorkflowPage;
