import NodeJslt from "apps/components/Workflow/nodes/NodeJslt";
import UtilManager from "../utils/util_manager";
import NodeAas from "apps/components/Workflow/nodes/NodeAas";
import NodeSet from "apps/components/Workflow/nodes/NodeSet";
import NodeCopy from "apps/components/Workflow/nodes/NodeCopy";
import NodeProgram from "apps/components/Workflow/nodes/NodeProgram";
import NodeHttp from "apps/components/Workflow/nodes/NodeHttp";

export const TreeItemType = {
  MDT: "MDT",
  SubModel: "SubModel",
  Element: "Element",
};

export const WorkflowNodeType = {
  set: NodeSet,
  copy: NodeCopy,
  program: NodeProgram,
  http: NodeHttp,
  jslt: NodeJslt,
  aas: NodeAas,
};

export const RunStatus = {
  ALL: "ALL",
  STOPPED: "STOPPED",
  STOPPING: "STOPPING",
  STARTING: "STARTING",
  RUNNING: "RUNNING",
  FAILED: "FAILED",
};

export const workflowItemData = {
  type: "",
  title: "",
  item: null,
};

export const TaskType = {
  SET: "mdt.task.builtin.SetTask",
  COPY: "mdt.task.builtin.CopyTask",
  PROGRAM: "mdt.task.builtin.ProgramTask",
  HTTP: "mdt.task.builtin.HttpTask",
  JSLT: "mdt.task.builtin.JsltTask",
  AAS: "mdt.task.builtin.AASOperationTask",
};

export const OptionType = {
  STRING: "string",
  BOOLEAN: "boolean",
  ARRAY: "array",
  MULTILINE: "multiline",
  TWIN_REF: "twin_ref",
  SUBMODEL_REF: "submodel_ref",
  SME_REF: "sme_ref",
};

export const VariableType = {
  INPUT: "INPUT",
  OUTPUT: "OUTPUT",
};

//#region GENESIS 데이터 정의

export const GenesisVariableData = {
  name: "",
  kind: VariableType.INPUT,
  valueReference: null,
};

export const GenesisValueReferenceData = {
  twinId: "",
  submodelIdShort: "",
  idShortPath: "",
};

export const GenesisOptionData = {
  name: "",
  optionType: OptionType.STRING,
};

export const GenesisTaskData = {
  id: "",
  type: TaskType.SET,
  dependencies: [],
  variables: [],
  options: [],
  labels: [],
};

//#endregion

export const useGenesisDataManager = () => {
  const { CloneDeep } = UtilManager();

  const GET_TASKLABEL = (type) => {
    let label = "";

    switch (type) {
      case TaskType.SET:
        label = "SET";
        break;
      case TaskType.COPY:
        label = "COPY";
        break;
      case TaskType.PROGRAM:
        label = "PROGRAM";
        break;
      case TaskType.HTTP:
        label = "HTTP";
        break;
      case TaskType.JSLT:
        label = "JSLT";
        break;
      case TaskType.AAS:
        label = "AAS";
        break;
      default:
        break;
    }

    return label;
  };

  const GET_NODETYPE = (type) => {
    let label = "";

    switch (type) {
      case TaskType.SET:
        label = "set";
        break;
      case TaskType.COPY:
        label = "copy";
        break;
      case TaskType.PROGRAM:
        label = "program";
        break;
      case TaskType.HTTP:
        label = "http";
        break;
      case TaskType.JSLT:
        label = "jslt";
        break;
      case TaskType.AAS:
        label = "aas";
        break;
      default:
        break;
    }

    return label;
  };

  const GET_TASKLIST = () => {
    let list = [];

    list.push(Get_Origin_TaskData(TaskType.SET));
    list.push(Get_Origin_TaskData(TaskType.COPY));
    list.push(Get_Origin_TaskData(TaskType.PROGRAM));
    list.push(Get_Origin_TaskData(TaskType.HTTP));
    list.push(Get_Origin_TaskData(TaskType.JSLT));
    list.push(Get_Origin_TaskData(TaskType.AAS));

    return list;
  };

  const Get_Origin_TaskData = (type) => {
    let base = CloneDeep(GenesisTaskData);

    switch (type) {
      case TaskType.SET:
        base.type = TaskType.SET;
        base.variables.push(Get_Origin_VariableData("to", VariableType.OUTPUT));
        base.options.push(Get_Origin_OptionData("value", OptionType.STRING));
        break;
      case TaskType.COPY:
        base.type = TaskType.COPY;
        base.variables.push(
          Get_Origin_VariableData("from", VariableType.INPUT)
        );
        base.variables.push(Get_Origin_VariableData("to", VariableType.OUTPUT));
        break;
      case TaskType.PROGRAM:
        base.type = TaskType.PROGRAM;
        base.variables.push(
          Get_Origin_VariableData("Data1", VariableType.INPUT)
        );
        base.variables.push(
          Get_Origin_VariableData("Data2", VariableType.INPUT)
        );
        base.variables.push(
          Get_Origin_VariableData("Result", VariableType.OUTPUT)
        );
        base.options.push(Get_Origin_OptionData("command", OptionType.ARRAY));
        base.options.push(
          Get_Origin_OptionData("workingDirectory", OptionType.STRING)
        );
        base.options.push(Get_Origin_OptionData("timeout", OptionType.STRING));
        break;
      case TaskType.HTTP:
        base.type = TaskType.HTTP;
        base.variables.push(
          Get_Origin_VariableData("Data1", VariableType.INPUT)
        );
        base.variables.push(
          Get_Origin_VariableData("Data2", VariableType.INPUT)
        );
        base.variables.push(
          Get_Origin_VariableData("Result", VariableType.OUTPUT)
        );
        base.options.push(Get_Origin_OptionData("url", OptionType.STRING));
        base.options.push(Get_Origin_OptionData("timeout", OptionType.STRING));
        base.options.push(Get_Origin_OptionData("logger", OptionType.STRING));
        break;
      case TaskType.JSLT:
        base.type = TaskType.JSLT;
        base.variables.push(
          Get_Origin_VariableData("Data1", VariableType.INPUT)
        );
        base.variables.push(
          Get_Origin_VariableData("Result", VariableType.OUTPUT)
        );
        base.options.push(Get_Origin_OptionData("expr", OptionType.MULTILINE));
        break;
      case TaskType.AAS:
        base.type = TaskType.AAS;
        base.options.push(
          Get_Origin_OptionData("operation", OptionType.SME_REF)
        );
        base.options.push(Get_Origin_OptionData("async", OptionType.BOOLEAN));
        base.options.push(Get_Origin_OptionData("timeout", OptionType.STRING));
        break;
      default:
        break;
    }

    return base;
  };

  const Get_Origin_OptionData = (name, type) => {
    let base = CloneDeep(GenesisOptionData);

    switch (type) {
      case OptionType.STRING:
        base.name = name;
        base.optionType = OptionType.STRING;
        base.value = "";
        break;
      case OptionType.BOOLEAN:
        base.name = name;
        base.optionType = OptionType.BOOLEAN;
        base.value = "";
        break;
      case OptionType.ARRAY:
        base.name = name;
        base.optionType = OptionType.ARRAY;
        base.values = [];
        break;
      case OptionType.MULTILINE:
        base.name = name;
        base.optionType = OptionType.MULTILINE;
        base.lines = "";
        break;
      case OptionType.TWIN_REF:
        base.name = name;
        base.optionType = OptionType.TWIN_REF;
        base.twinId = "";
        break;
      case OptionType.SUBMODEL_REF:
        base.name = name;
        base.optionType = OptionType.SUBMODEL_REF;
        base.twinId = "";
        base.submodelIdShort = "";
        break;
      case OptionType.SME_REF:
        base.name = name;
        base.optionType = OptionType.SME_REF;
        base.twinId = "";
        base.submodelIdShort = "";
        base.idShortPath = "";
        break;
      default:
        break;
    }

    return base;
  };

  const Get_Origin_VariableData = (name, type) => {
    let base = CloneDeep(GenesisVariableData);

    switch (type) {
      case VariableType.INPUT:
        base.name = name;
        base.kind = VariableType.INPUT;
        base.valueReference = Get_Origin_ValueReferenceData();
        break;
      case VariableType.OUTPUT:
        base.name = name;
        base.kind = VariableType.OUTPUT;
        base.valueReference = Get_Origin_ValueReferenceData();
        break;
      default:
        break;
    }

    return base;
  };

  const Get_Origin_ValueReferenceData = () => {
    let base = CloneDeep(GenesisValueReferenceData);
    return base;
  };

  return {
    GET_NODETYPE,
    GET_TASKLABEL,
    GET_TASKLIST,
    Get_Origin_TaskData,
    Get_Origin_OptionData,
    Get_Origin_VariableData,
    Get_Origin_ValueReferenceData,
  };
};

export const useConvert = () => {
  const CREATE_TREEITEM = (data, type, parent = null) => {
    let result = {
      id: "",
      label: "",
      parent: null,
      type: type,
      data: data,
      children: [],
    };

    switch (type) {
      case TreeItemType.MDT:
        result.id = data.id;
        result.label = data.id;
        break;
      case TreeItemType.SubModel:
        result.id = parent.id + "-" + data.idShort;
        result.label = data.idShort;
        result.parent = parent;
        break;
      case TreeItemType.Element:
        result.id = parent.id + "-" + data.idShort;
        result.label = data.idShort;
        result.parent = parent;
        delete result.children;
        break;
      default:
        break;
    }

    return result;
  };

  const CONVERT_MDTLIST_TO_TREELIST = (list) => {
    let resultlist = [];

    list.forEach((element) => {
      let item = CREATE_TREEITEM(element, TreeItemType.MDT);

      if (element.status === RunStatus.RUNNING) {
        element.submodels.forEach((submodel) => {
          let model = CREATE_TREEITEM(submodel, TreeItemType.SubModel, item);

          item.children.push(model);
        });

        resultlist.push(item);
      }
    });

    return resultlist;
  };

  return {
    CREATE_TREEITEM,
    CONVERT_MDTLIST_TO_TREELIST,
  };
};
