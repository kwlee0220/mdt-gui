import { createSlice } from "@reduxjs/toolkit";

const user = JSON.parse(localStorage.getItem("user"));

const initialState = user
  ? {
      isLoggedIn: true,
      id: user.id,
      user: user,
    }
  : {
      isLoggedIn: false,
      id: null,
      user: null,
    };

export const authSlice = createSlice({
  name: "auth",
  initialState,
  reducers: {
    login: (state, action) => {
      let user = action.payload;

      state.isLoggedIn = true;
      state.id = user.userid;
      state.user = user;

      localStorage.setItem("user", JSON.stringify(user));
    },
    logout: (state) => {
      localStorage.removeItem("user");

      state.isLoggedIn = false;
      state.id = null;
    },
    setUser: (state, action) => {
      let user = action.payload;
      state.id = user.userid;
      state.user = user;

      localStorage.setItem("user", JSON.stringify(user));
    },
  },
});

export const { login, logout, setUser } = authSlice.actions;
